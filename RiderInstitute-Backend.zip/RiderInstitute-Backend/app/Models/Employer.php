<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Employer extends Model
{
    use HasFactory;
    protected $fillable = [
        'Company_Name',
        'Industry',
        'Number_of_employees',
        'User_id',
        'Website',
        'person_phone_number',
        // 'state',
        // 'L_G_A',
        'Email',
        'Telephone_Number',
        'Address',
    ];
}

<?php

namespace App\Http\Resources;

use App\Models\Employer;
use App\Models\Post_Job;
use App\Models\User;
use Illuminate\Http\Resources\Json\JsonResource;

class AppliedEmployee extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
        "id"=>$this->id,
        "name"=>$this->name,
        // "postedjob_id"=>$this->postedjob_id,
        // "user_id"=>$this->user_id,
        "phone_number"=>$this->phone_number,
        // "employer_id"=>$this->employer_id,
        "companyname"=>Employer::where(["user_id"=>$this->employer_id])->first()->Company_Name,
        "companypic"=>User::where(["id"=>$this->employer_id])->first()->picture,
        // "employeename"=>User::where(["id"=>$this->user_id])->first()->name,
        "role"=>Post_Job::where(["id"=>$this->postedjob_id])->first()->role,
        "data"=>$this->created_at,
        "status"=>$this->status,
        ];
    }
}

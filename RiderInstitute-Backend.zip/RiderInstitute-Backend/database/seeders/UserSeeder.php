<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('riders')->insert([
          'name'=>Str::random(50),
          'role'=>Str::random(50).'@gmail.com',
          'salaryrange'=>Str::random(50),
          'state'=>Str::random(50),
          'email'=>Str::random(50),
          'age'=>Str::random(50),
          'Qualification'=>Str::random(50),
          'ExperienceLength'=>Str::random(50),
          'JobLevel'=>Str::random(50),
          'SalaryCurrency'=>Str::random(50),

      ]);
    }
}


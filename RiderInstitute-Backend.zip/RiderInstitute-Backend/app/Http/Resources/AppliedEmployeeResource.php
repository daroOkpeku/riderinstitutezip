<?php

namespace App\Http\Resources;

use App\Models\Employee;
use App\Models\EmployeeHired;
use App\Models\Employer;
use App\Models\EmployerPlan;
use App\Models\User;
use App\Models\Post_Job;
use Illuminate\Http\Resources\Json\JsonResource;

class AppliedEmployeeResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            "id"=>$this->id,
            "name"=>$this->name,
            "postedjob_id"=>$this->postedjob_id,
            "user_id"=>$this->user_id,
            "phone_number"=>$this->phone_number,
            "qualification"=>$this->qualification,
            "experiencelenght"=>$this->experiencelenght,
            "appliant_cv"=>$this->appliant_cv,
             'status'=>$this->status,
             "employer_id"=>$this->employer_id,
             "employer_status"=>$this->employer_status,
             "reason"=>$this->reason,
             "explaination"=>$this->explaination,
             "decisiondate"=>$this->decisiondate,
             'public_id'=>$this->public_id,
             "posted_job_sub"=>Post_Job::where(["id"=>$this->postedjob_id])->first()->subscriptionplan,
             "exit_reason"=>EmployerPlan::where(["nameofplan"=>Post_Job::where(["id"=>$this->postedjob_id])->first()->subscriptionplan])->first()->exit_reason,
            'addinfo'=>Employee::where(['user_id'=>$this->user_id])->first(),
            'user'=>User::where(['id'=>$this->user_id])->first(),
            "employer"=>Employer::where(["user_id"=>$this->employer_id])->first(),
            "hired"=>EmployeeHired::where(["employee_id"=>$this->user_id, "employer_id"=>$this->employer_id])->first(),
        ];
    }
}

<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use CloudinaryLabs\CloudinaryLaravel\Facades\Cloudinary;
use MailchimpTransactional\ApiClient;
class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function getusers(){
      return  auth()->user();
    }

    public function countPages($path) {
        $pdftext = file_get_contents($path);
        $num = preg_match_all("/\/Page\W/", $pdftext, $dummy);
        return $num;
    }

    public function cloud($data){
        $name = $data->getClientOriginalName();
        $color = explode(".", $name);
        $uploadedFileUrl = Cloudinary::uploadFile($data->getRealPath(),[
            "public_id"=>$color[0].'.docx',
            "resource_type"=>'image',
            "raw_convert" => "aspose",
            "pages" => TRUE,
            "use_filename" => TRUE,
            "unique_filename" => FALSE,
        ]);
        return $uploadedFileUrl;
    }


    public static function SendEmail($name, $email, $verification_code){

        $message = [
            "from_email" => "info@dellyman.com",
            "subject" => "RidersInstitute",
            "html" => "
  <section class='margin:0px; padding:0px; box-sizing: border-box; ' >
  <div class='  width:70%; padding:1rem; display:flex; align-items: center; justify-content: center;'>
      <span class='  width:200px; display:flex; align-items: center; justify-content: center;'>
      <img src='https://res.cloudinary.com/okpeku/image/upload/v1646843932/WhatsApp_Image_2021-10-01_at_12.05.14_PM_imzhyw.png'/>

      </span>
  </div>
         <div class='width:60%;  display: flex; flex-direction: column;'>
         <p>hello,$name</p>
         <p> Welcome to Rider Institute.Kindly click the link below to activate your account</p>
         <p>http://dev.ridersinstitute.com/Check/$verification_code</p>
         <p>Rider Institute team</p>
         </diV>
  </section>

  ",
                    "to" => [
                        [
                            "email" =>$email,
                            "type" => "to"
                        ]
                    ]
                ];

                $mailchimp =new ApiClient();
                //new MailchimpTransactional\ApiClient();
                $mailchimp->setApiKey('L_npXuJr1AGIliqQjno6Jw');
              // "reject_reason": null
                $response = $mailchimp->messages->send(["message" => $message]);
    }



    public static function JobEmail($id, $role, $email, $name, $companyname, $location){

        $message = [
            "from_email" => "info@dellyman.com",
           "subject" => "RidersInstitute",
             "html" => "
         <section class='margin:0px; padding:0px; box-sizing: border-box; ' >
         <div class='  width:70%; padding:1rem; display:flex; align-items: center; justify-content: center;'>
             <span class='  width:200px; display:flex; align-items: center; justify-content: center;'>
             <img src='https://res.cloudinary.com/okpeku/image/upload/v1646843932/WhatsApp_Image_2021-10-01_at_12.05.14_PM_imzhyw.png'/>
             </span>
         </div>
                <div class='width:60%;  display: flex; flex-direction: column;'>
                <p>$name, We Have a Roles For You</p>
                <p> $companyname  Company in $location</p>
                <p>please click on this link </p>
                <p>http://dev.ridersinstitute.com/job/$id/$role</p>
                <p> to view the job</p>
                </diV>
         </section>
         ",
          "to" => [
          [
         "email" =>$email,
         "type" => "to"
                     ]
                ]
               ];

              $mailchimp =new ApiClient();
             $mailchimp->setApiKey('L_npXuJr1AGIliqQjno6Jw');
              $response = $mailchimp->messages->send(["message" => $message]);

    }

    public function Approvedanddecline($name, $code,  $email){
        $present = Carbon::now();
        $presenttime = Carbon::createFromFormat('Y-m-d H:i:s', $present );
        $message = [
            "from_email" => "info@dellyman.com",
           "subject" => "RidersInstitute",
             "html" => "
             <section class='margin:0px; padding:0px; box-sizing: border-box; ' >
             <div class='  width:70%; padding:1rem; display:flex; align-items: center; justify-content: center;'>
                 <span class='  width:200px; display:flex; align-items: center; justify-content: center;'>
                 <img src='https://res.cloudinary.com/okpeku/image/upload/v1646843932/WhatsApp_Image_2021-10-01_at_12.05.14_PM_imzhyw.png'/>
                 </span>
             </div>
                    <div class='width:60%;  display: flex; flex-direction: column;'>
                    <p>$name your job posting has been</p>
                    <p>approved with the code $code</p>
                    </diV>
             </section>
          ",
          "to" => [
          [
         "email" =>$email,
         "type" => "to"
                     ]
                ]
               ];

              $mailchimp =new ApiClient();
             $mailchimp->setApiKey('L_npXuJr1AGIliqQjno6Jw');
              $response = $mailchimp->messages->send(["message" => $message]);
    }


    public static function Setup($name, $verification_code, $email){
        $message = [
            "from_email" => "info@dellyman.com",
            "subject" => "RidersInstitute",
            "html" => "
<section class='margin:0px; padding:0px; box-sizing: border-box; ' >
<div class='  width:70%; padding:1rem; display:flex; align-items: center; justify-content: center;'>
    <span class='  width:200px; display:flex; align-items: center; justify-content: center;'>
    <img src='https://res.cloudinary.com/okpeku/image/upload/v1646843932/WhatsApp_Image_2021-10-01_at_12.05.14_PM_imzhyw.png'/>
    </span>
</div>
       <div class='width:60%;  display: flex; flex-direction: column;'>
       <p>hello,$name</p>
       <p>Welcome to Rider Institute.Kindly click the link below to activate your account</p>
       <p>http://dev.ridersinstitute.com/Set_up/$verification_code</p>
       <p>Rider Institute team</p>
       </diV>
</section>
",
"to" => [
    [
        "email" =>$email,
        "type" => "to"
    ]
]
];

$mailchimp =new ApiClient();
//new MailchimpTransactional\ApiClient();
$mailchimp->setApiKey('L_npXuJr1AGIliqQjno6Jw');
// "reject_reason": null
$response = $mailchimp->messages->send(["message" => $message]);
    }
    

 
}

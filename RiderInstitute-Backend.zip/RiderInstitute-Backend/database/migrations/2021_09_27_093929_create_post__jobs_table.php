<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePostJobsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('post__jobs', function (Blueprint $table) {
            $table->id();
            $table->tinyText('companyname')->nullable();
            $table->longText('jobSummary')->nullable();
            $table->tinyText('role')->nullable();
            $table->tinyText('salaryrange')->nullable();
            // $table->tinyText('City');
            //in_draft
            // $table->boolean('indraft')->nullable()->default(0);
            // $table->boolean('expired_status')->default(0);
            // $table->boolean('approved_status')->default(0);
           // $table->tinyText('statusofsub')->nullable();
            $table->tinyText('subscriptionplan')->nullable();
            $table->tinyText('location')->nullable();
            $table->tinyText('age_range')->nullable();
            $table->tinyText('email')->nullable();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->foreign('user_id')->references('id')->on('users');
            $table->tinyText('riders_location')->nullable();
            $table->longText('job_description')->nullable();
            $table->tinyText('Qualification')->nullable();
            $table->tinyText('ExperienceLength')->nullable();
            $table->tinyText('JobLevel')->nullable();
            $table->tinyText('SalaryCurrency')->nullable();
            $table->tinyText('job_code')->nullable();
            $table->longText('requirements')->nullable();
            $table->longText('figure')->nullable();
            $table->boolean('changestatus')->default(0)->nullable();
            $table->longText('statusofsub')->nullable();  
            $table->boolean('indraft')->default(0)->nullable();
            $table->boolean('reject_status')->default(0)->nullable();
            $table->tinyText('end_date')->nullable();
            $table->timestamps();
        });



    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('post__jobs');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AppliedJob extends Model
{
    use HasFactory;
    // $table->tinyText('name');
    // $table->unsignedBigInteger('postedjob_id')->nullable();
    // $table->foreign('postedjob_id')->references('id')->on('post__jobs');
    // $table->unsignedBigInteger('employee_id')->nullable();
    // $table->foreign('employee_id')->references('id')->on('employees');
    // $table->tinyText('phone_number');
    // $table->tinyText('qualification');
    // $table->tinyText('experiencelenght');
    // $table->tinyText('appliant_cv');
    protected $fillable = [
      'name',
      'postedjob_id',
      'user_id',
      'phone_number',
      'employer_id',
      'public_id',
      'qualification',
      'experiencelenght',
      'appliant_cv',
      'status'
    ];

    public function user() {
        return $this->belongsTo(Applicant::class, 'user_id', 'id');
    }


}

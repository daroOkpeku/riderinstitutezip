<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddAuthorToEmployeeHiredsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('employee_hireds', function (Blueprint $table) {
            $table->unsignedBigInteger('posted_id')->nullable();
            $table->foreign('posted_id')->references('id')->on('post__jobs');
            $table->longText("explaination")->nullable();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('employee_hireds', function (Blueprint $table) {
            //
        });
    }
}

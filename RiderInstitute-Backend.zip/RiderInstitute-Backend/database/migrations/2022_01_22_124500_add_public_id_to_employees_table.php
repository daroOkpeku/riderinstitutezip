<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddPublicIdToEmployeesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('employees', function (Blueprint $table) {
            $table->tinyText("nin_slipld")->nullable();
            $table->tinyText("rider_cardId")->nullable();
            $table->tinyText("driving_licenseId")->nullable();
            $table->tinyText("prove_of_addressId")->nullable();
            $table->tinyText("passport_photographId")->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('employees', function (Blueprint $table) {

        });
    }
}

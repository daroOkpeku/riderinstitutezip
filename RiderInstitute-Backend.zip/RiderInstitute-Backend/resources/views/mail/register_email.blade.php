hello {{ $email_data['name'] }}
<br><br>
welcome to Rider Institute
<br>

please  verify your email. Thank you
<br><br>
<a href="https://ridersinstitute.netlify.app/Check/{{ $email_data['verification_code'] }}">click here</a>

<br><br>
Thank you
<br>

 {{$qualified['name']}} , We Have a Roles For You
<br><br>
From {{ $qualified['companyname'] }} Company
<br>
in {{ $qualified['joblocation'] }}

please
<br><br>
<a href="https://ridersinstitute.netlify.app/job/{{ $qualified['posted_id'] }}/{{ $qualified['jobTite'] }}">click here</a>

<br><br>
to view the job
<br>

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddPageToEmployeesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('employees', function (Blueprint $table) {
         $table->tinyText('nin_slippage')->nullable();
         $table->tinyText('rider_cardpage')->nullable();
         $table->tinyText('driving_licensepage')->nullable();
         $table->tinyText('prove_of_addresspage')->nullable();
         $table->tinyText('passport_photographpage')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('employees', function (Blueprint $table) {
            //
        });
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VerifieldEmployee extends Model
{
    use HasFactory;


    protected $fillable = [
        'employee_id',
        'nin_slippage',
        'rider_cardpage',
        'driving_licensepage',
        'prove_of_addresspage',
        'passport_photographpage',
        'status',
    ];

}

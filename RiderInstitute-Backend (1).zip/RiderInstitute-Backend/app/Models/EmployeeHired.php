<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmployeeHired extends Model
{
    use HasFactory;
    protected $fillable = [
       'employee_id',
       'employer_id',
       'reason_by_employer',
       'reason_by_employee',
       'termination_by_employer',
       'termination_by_employee',
       'status',
       'date_started',
       'end_data',
       'posted_id',
       'explaination',
    ];
}

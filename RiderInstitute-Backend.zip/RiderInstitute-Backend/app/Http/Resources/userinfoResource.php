<?php

namespace App\Http\Resources;

use App\Models\Employee;
use Illuminate\Http\Resources\Json\JsonResource;

class userinfoResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        // "id": 2,
        // "name": "daro ighodaro",
        // "email": "sokpeku@yahoo.com",
        // "email_verified_at": null,
        // "Address": null,
        // "phone": null,
        // "Role": "Employee",
        // "picture": null,
        // "verification_code": "69c3fe305c50b4b9a7fc14abff5da63c9814e221",
        // "is_verified": true,
        // "created_at": "2021-12-15T18:57:04.000000Z",
        // "updated_at": "2021-12-15T18:59:16.000000Z",
        // "pivot": {
        //     "postedjob_id": 3,
        //     "user_id": 2
        // }
        return [
         'id'=>$this->id,
        'name'=>$this->name,
        'email'=>$this->email,
        'role'=>$this->Role,
        'picture'=>$this->picture,
        "created_at"=>$this->created_at,
        "updated_at"=>$this->updated_at,
        'addinfo'=>Employee::where(['user_id'=>$this->id])->first(),

        ];
    }
}

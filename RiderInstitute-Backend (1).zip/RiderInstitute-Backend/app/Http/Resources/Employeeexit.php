<?php

namespace App\Http\Resources;

use App\Models\Employer;
use App\Models\User;
use Illuminate\Http\Resources\Json\JsonResource;

class Employeeexit extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {

        return [
            "id" => $this->id,
            "reason_by_employer" => $this->reason_by_employer,
            "reason_by_employee" => $this->reason_by_employee,
            "termination_by_employer" => $this->termination_by_employer,
            "termination_by_employee"=> $this->termination_by_employee,
            "status"=>$this->status,
            "created_at"=>$this->created_at,
            "updated_at"=>$this->updated_at,
            "posted_id"=>$this->posted_id,
            "picture"=>User::where(["id"=>$this->employer_id])->first()->picture,
            "companyname"=>Employer::where(['user_id'=>$this->employer_id])->first()->Company_Name,
            "explaination"=>$this->explaination,
            "date_started"=>$this->date_started,
            "end_data"=>$this->end_data,
             "recommend_candiate"=>$this->recommend_candiate,
             "employe_candiate_again"=>$this->employe_candiate_again,
             "date_started"=>$this->date_started,
             "end_data"=>$this->end_data
        ];
    }
}

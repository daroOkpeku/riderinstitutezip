<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppliedJobsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //employer_id
        Schema::create('applied_jobs', function (Blueprint $table) {
            $table->id();
            $table->tinyText('name');
            $table->unsignedBigInteger('postedjob_id')->nullable();
            $table->foreign('postedjob_id')->references('id')->on('post__jobs');
            $table->unsignedBigInteger('user_id')->nullable();
            $table->foreign('user_id')->references('id')->on('users');
            $table->tinyText('phone_number');
            $table->unsignedBigInteger('employer_id')->nullable();
            $table->foreign('employer_id')->references('id')->on('users');
            $table->tinyText('public_id');
            $table->tinyText('qualification');
            $table->tinyText('experiencelenght');
            $table->tinyText('appliant_cv');
            $table->tinyText('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('applied_jobs');
    }
}

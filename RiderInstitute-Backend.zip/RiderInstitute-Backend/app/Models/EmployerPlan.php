<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmployerPlan extends Model
{
    use HasFactory;
    protected $fillable = [
       'nameofplan',
       'numberofemployee',
       'pricepermonth',
       'description',
       'exit_reason',
       'download',
       'number_of_download'

    ];

}

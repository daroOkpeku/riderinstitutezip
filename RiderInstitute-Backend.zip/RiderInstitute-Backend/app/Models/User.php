<?php

namespace App\Models;
use Illuminate\Support\Facades\Route;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'name',
        'email',
        'Address',
        'phone',
        'Role',
        'employer',
        'carrier',
        'picture',
        'type_status',
        'password',
        // 'suspensed',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
    public function JobsPosting() {
        return $this->hasMany(Post_Job::class)->orderBy('id', 'DESC');
    }
     public function Jobsearch(){
         return $this->hasMany(Post_Job::class,'user_id')->orderBy('id', 'DESC');
     }
    public function paid(){
        return $this->hasOne(Payment::class);
    }

    public function Employer_exist(){
        return $this->hasOne(Employer::class);
    }
    public function employee_cv(){
        return $this->hasMany(Qualifield_Employee::class,);
    }

 public function PaymentHistory(){
     return $this->hasMany(PaymentHistory::class);

 }



   public function rejob(){
       return $this->hasMany(Post_Job::class)->orderBy('id', 'DESC');
   }

    public function run(){
        return $this->hasMany(Post_Job::class,'id');
    }

     public function applicantinfo(){
         return $this->hasMany(AppliedJob::class,'user_id')->orderBy('id', 'DESC');
     }

     public function findemployee(){
         return $this->hasOne(Employee::class,'user_id');
     }

     public function hiredemployee(){
         return $this->hasMany(EmployeeHired::class,"employer_id");
     }


     public function employeehired(){
        return $this->hasMany(EmployeeHired::class,"employee_id");
    }




     //working
    // many to many connnection
    // it is connecting  the post_job, qualifield_employee and rider model
    // if u want to do many connection for rider model u have to do  return $this->belongsToMany(Post_job::class, 'qualifield__employees', 'posted_id', 'rider_id');
    // qualifield__employees table is what is connecting the two tables together using  posted_id, rider_id
    // public function ridersq(){
    //     return $this->belongsToMany(Rider::class, 'qualifield__employees', 'posted_id', 'rider_id');
    // }

//    public function Applied(){
//     return $this->belongsToMany(Post_Job::class, 'applied_jobs', 'postedjob_id');

//      }


}

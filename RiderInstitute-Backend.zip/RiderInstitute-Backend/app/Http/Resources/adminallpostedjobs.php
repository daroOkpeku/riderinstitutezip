<?php

namespace App\Http\Resources;

use App\Models\Employer;
use Illuminate\Foundation\Auth\User;
use Illuminate\Http\Resources\Json\JsonResource;

class adminallpostedjobs extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
         'id'=>$this->id,
        'companyname'=>$this->companyname,
        'jobSummary'=>$this->jobSummary,
        'role'=>$this->role,
        'salaryrange'=>$this->salaryrange,
        'in_draft'=>$this->in_draft,
        'status'=>$this->status,
        'subscriptionplan'=>$this->subscriptionplan,
        'location'=>$this->location,
        'age_range'=>$this->age_range,
        'email'=>$this->email,
        'user_id'=>$this->user_id,
        'job_description'=>$this->job_description,
        'Qualification'=>$this->Qualification,
        'ExperienceLength'=>$this->ExperienceLength,
        'JobLevel'=>$this->JobLevel,
        'SalaryCurrency'=>$this->SalaryCurrency,
        'job_code'=>$this->job_code,
        'created_at'=>$this->created_at,
        // 'reject_status',
          'statusofsub'=>$this->statusofsub,
          'indraft'=>$this->indraft,
        'end_date'=>$this->end_date,
        'user'=>User::where(["id"=>$this->user_id])->first(),
        'employer'=>Employer::where(['user_id'=>$this->user_id])->first()
        ];
    }
}

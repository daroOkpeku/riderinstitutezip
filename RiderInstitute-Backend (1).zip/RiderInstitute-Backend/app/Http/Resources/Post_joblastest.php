<?php

namespace App\Http\Resources;

use App\Models\AppliedJob;
use App\Models\Employer;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;
class Post_joblastest extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'companyname'=>$this->companyname,
            'jobSummary'=>$this->jobSummary,
            'role'=>$this->role,
            'salaryrange'=>$this->salaryrange,
            'in_draft'=>$this->in_draft,
            'status'=>$this->status,
            'subscriptionplan'=>$this->subscriptionplan,
            'location'=>$this->location,
            'age_range'=>$this->age_range,
            'email'=>$this->email,
            'user_id'=>$this->user_id,
            'job_description'=>$this->job_description,
            'Qualification'=>$this->Qualification,
            'ExperienceLength'=>$this->ExperienceLength,
            'JobLevel'=>$this->JobLevel,
            'SalaryCurrency'=>$this->SalaryCurrency,
            'job_code'=>$this->job_code,
            'created_at'=>Carbon::createFromFormat('Y-m-d H:i:s', $this->created_at)->diffForHumans(),
           // ''stat=>Carbon::createFromFormat('Y-m-d H:i:s', $this->created_at),
           'state_date'=>$this->created_at,
            'end_date'=>$this->end_date,
            'picture'=>User::where(['id'=>$this->user_id])->first()->picture,
            "Industry"=>Employer::where(['user_id'=>$this->user_id])->first()->Industry,
            "applied"=>count(AppliedJob::where(["postedjob_id"=>$this->id])->get())
        ];
    }
}
